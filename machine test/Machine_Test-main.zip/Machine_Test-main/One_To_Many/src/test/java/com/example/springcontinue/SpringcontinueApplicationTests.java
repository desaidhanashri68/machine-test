package com.example.springcontinue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcontinueApplicationTests {

	@Test
	void contextLoads() {
	}

}
