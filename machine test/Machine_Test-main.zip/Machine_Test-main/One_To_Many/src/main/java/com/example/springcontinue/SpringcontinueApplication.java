package com.example.springcontinue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcontinueApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcontinueApplication.class, args);
	}

}
